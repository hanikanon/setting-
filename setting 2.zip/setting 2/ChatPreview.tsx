import React from "react";
import { ArrowLeft, Search, Phone, Video, MoreVertical, Plus, Smile, Mic, FileText, Play } from "lucide-react";
import { THEMES, WALLPAPERS, type ThemeId, type AccentId, type BubbleStyle } from "./SettingsContext";


const CryptvoraAppIcon = ({ size = 32 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="100" height="100" rx="22" fill="#0A0A10" />
    <path d="M32 36 C12 36, 12 64, 32 64 C46 64, 50 50, 50 50 C50 50, 54 36, 68 36 C88 36, 88 64, 68 64 C54 64, 50 50, 50 50 C50 50, 46 36, 32 36 Z" fill="transparent" stroke="white" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);


type ChatPreviewProps = {
  theme: ThemeId;
  accent: AccentId;
  radius: number;
  bubble: BubbleStyle;
  wallpaper: string;
  fontSize: string; // we can map small/medium/large/xl to pixel values
  blur: number;
  isCard?: boolean; // if true, hide some elements for smaller size
};

export const ChatPreview = React.memo(function ChatPreview({
  theme,
  accent,
  radius,
  bubble,
  wallpaper,
  fontSize,
  blur,
  isCard,
}: ChatPreviewProps) {
  const t = THEMES[theme];
  // We need to resolve colors.
  // For the actual app, these are CSS variables. Here, we can use the theme object's values.
  
  // map radius for bubble
  const getBubbleRadius = (side: "left" | "right") => {
    const r = radius + "px";
    if (bubble === "square") return "8px";
    if (bubble === "rounded") return "22px";
    if (bubble === "tail")
      return side === "right" ? `${r} ${r} 4px ${r}` : `${r} ${r} ${r} 4px`;
    return r;
  };

  return (
    <div 
      className="relative flex flex-col w-full h-full overflow-hidden"
      style={{ 
        background: `${WALLPAPERS[wallpaper as keyof typeof WALLPAPERS]?.value}, ${t.wallpaper}, ${t.surface}`,
        color: t.fg,
        fontFamily: "var(--font-sans)",
      }}
    >
      {/* Header */}
      <div 
        className="flex items-center gap-2 sm:gap-3 px-3 py-2 sm:py-2.5 z-10 border-b"
        style={{ 
          background: `color-mix(in oklab, ${t.surface} 80%, transparent)`,
          backdropFilter: `blur(${blur}px)`,
          borderColor: t.border
        }}
      >
        <ArrowLeft size={isCard ? 16 : 20} className="shrink-0" style={{ color: t.fg }} />
        <div className="relative shrink-0">
          <img 
            src="https://i.pravatar.cc/150?u=elena" 
            alt="Elena" 
            className={`${isCard ? 'w-6 h-6' : 'w-9 h-9'} rounded-full object-cover`} 
          />
          <div className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-transparent bg-green-500" style={{ borderColor: t.surface }} />
        </div>
        <div className="flex-1 min-w-0">
          <div className={`${isCard ? 'text-[11px]' : 'text-[15px]'} font-semibold truncate`} style={{ color: t.fg }}>Elena Rostova</div>
          <div className={`${isCard ? 'text-[9px]' : 'text-[12px]'} truncate text-green-500`}>typing...</div>
        </div>
        {!isCard && (
          <div className="flex items-center gap-3 shrink-0" style={{ color: t.fg }}>
            <Search size={18} />
            <Phone size={18} />
            <Video size={18} />
            <MoreVertical size={18} />
          </div>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 flex flex-col gap-3 p-3 overflow-hidden justify-end">
        {/* Left Bubble - App Icon */}
        <div className="flex justify-start">
          <div 
            className="flex flex-col gap-2 p-2.5 shadow-sm"
            style={{ 
              background: t.surface2, 
              borderRadius: getBubbleRadius("left"),
              maxWidth: "85%"
            }}
          >
            <div className="flex items-center gap-3">
              <CryptvoraAppIcon size={isCard ? 24 : 32} />
              <div className="flex flex-col">
                <span className={`${isCard ? 'text-[10px]' : 'text-[13px]'} font-bold`} style={{ color: t.fg }}>Cryptvora</span>
                <span className={`${isCard ? 'text-[8px]' : 'text-[11px]'}`} style={{ color: t.muted }}>v2.0 Premium</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Left Bubble - File */}
        <div className="flex justify-start">
          <div 
            className="flex items-center gap-3 p-2.5 pr-4 shadow-sm"
            style={{ 
              background: t.surface2, 
              borderRadius: getBubbleRadius("left"),
              maxWidth: "85%"
            }}
          >
            <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: "color-mix(in oklab, var(--primary) 15%, transparent)", color: "var(--primary)" }}>
               <FileText size={20} />
            </div>
            <div className="flex flex-col">
              <span className={`${isCard ? 'text-[10px]' : 'text-[13px]'} font-medium truncate max-w-[120px]`} style={{ color: t.fg }}>Q3_Financial_Repo...</span>
              <span className={`${isCard ? 'text-[8px]' : 'text-[11px]'}`} style={{ color: t.muted }}>2.4 MB • PDF</span>
            </div>
          </div>
        </div>

        {/* Right Bubble - Text */}
        <div className="flex justify-end">
          <div 
            className="px-3.5 py-2 shadow-sm"
            style={{ 
              background: "var(--gradient-brand, var(--primary))", 
              color: "white",
              borderRadius: getBubbleRadius("right"),
              maxWidth: "85%",
              fontSize: isCard ? '10px' : fontSize,
              boxShadow: "0 4px 16px -4px color-mix(in oklab, var(--primary) 40%, transparent)"
            }}
          >
            Just sent the assets over. Let me know if you need anything else!
            <div className="text-[9px] text-right mt-1 opacity-70">17:33 ✓</div>
          </div>
        </div>
      </div>

      {/* Input Area */}
      <div 
        className="flex items-center gap-2 p-2 sm:p-3 z-10"
        style={{ background: t.surface }}
      >
        <div className={`flex-shrink-0 ${isCard ? "w-6 h-6" : "w-8 h-8"} rounded-full flex items-center justify-center shrink-0`} style={{ background: t.surface2, color: t.muted }}>
          <Plus size={isCard ? 14 : 18} />
        </div>
        <div 
          className="flex-1 flex items-center gap-2 px-3 py-1.5 rounded-full"
          style={{ background: t.surface2 }}
        >
          <Smile size={isCard ? 14 : 18} style={{ color: t.muted }} />
          <span className={`${isCard ? 'text-[10px]' : 'text-[13.5px]'}`} style={{ color: t.muted }}>Message</span>
        </div>
        <div className={`${isCard ? 'w-7 h-7' : 'w-9 h-9'} rounded-full flex items-center justify-center shrink-0 text-white`} style={{ background: "var(--primary)", boxShadow: "0 2px 10px -2px color-mix(in oklab, var(--primary) 50%, transparent)" }}>
          <Mic size={isCard ? 12 : 16} />
        </div>
      </div>
    </div>
  );
});
