import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, useLayoutEffect, type ReactNode } from "react";
const useIsomorphicLayoutEffect = typeof window !== "undefined" ? useLayoutEffect : useEffect;

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { SettingsProvider, themeStyle, useSettings } from "../components/settings/SettingsContext";
import { AnimatePresence, motion } from "framer-motion";
import { useRouterState } from "@tanstack/react-router";
import { Toaster } from "../components/ui/sonner";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Cryptvora — Settings" },
      {
        name: "description",
        content:
          "Premium native-feeling settings for Cryptvora, a community platform built for traders.",
      },
      { name: "author", content: "Cryptvora" },
      { property: "og:title", content: "Cryptvora — Settings" },
      {
        property: "og:description",
        content: "Premium native-feeling settings for Cryptvora.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        
<div id="ssr-loader" style={{ position: 'fixed', inset: 0, backgroundColor: 'oklch(0.11 0.006 280)', zIndex: 999999, transition: 'opacity 0.4s ease-out', pointerEvents: 'none', display: 'flex', justifyContent: 'center' }}>
  <div style={{ width: '100%', maxWidth: '560px', padding: '16px', display: 'flex', flexDirection: 'column', gap: '24px' }}>
    <div style={{ height: '36px', width: '36px', borderRadius: '12px', background: 'oklch(0.18 0.007 280)', opacity: 0.5 }} />
    <div style={{ height: '60px', width: '100%', borderRadius: '16px', background: 'oklch(0.145 0.007 280)', opacity: 0.5 }} />
    <div style={{ height: '300px', width: '100%', borderRadius: '24px', background: 'oklch(0.145 0.007 280)', opacity: 0.5 }} />
  </div>
</div>

        <script dangerouslySetInnerHTML={{ __html: `
          if (typeof window !== 'undefined') {
            
          }
        `}} />
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <SettingsProvider>
        <ThemedShell>
          <RouteTransition>
            <Outlet />
          </RouteTransition>
        </ThemedShell>
      </SettingsProvider>
    </QueryClientProvider>
  );
}



function ThemedShell({ children }: { children: ReactNode }) {
  const s = useSettings();
  const style = themeStyle(s.theme, s.accent, s.radius, s.fontSize, s.blur);
  useIsomorphicLayoutEffect(() => {
    const l = document.getElementById('ssr-loader');
    if(l) { l.style.opacity = '0'; setTimeout(() => l.remove(), 300); }
  }, []);
  
  return (
    <div style={style} className="h-svh w-full relative overflow-hidden">
      <div
        className="h-svh w-full relative"

        style={{ background: "var(--background)", color: "var(--foreground)" }}
      >
        {children}
        <Toaster />
      </div>
    </div>
  );
}


function RouteTransition({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const s = useSettings();
  const speed = s.motion === "fast" ? 0.14 : s.motion === "reduced" ? 0 : 0.24;
  
  return (
    <AnimatePresence mode="popLayout" initial={false}>
      <motion.div
        key={pathname}
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 1.04 }}
        transition={{ duration: speed, ease: [0.16, 1, 0.3, 1] }}
        style={{ width: '100%', height: '100%', position: 'absolute', top: 0, left: 0, overflowY: 'auto', overflowX: 'hidden', WebkitOverflowScrolling: 'touch' }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}
