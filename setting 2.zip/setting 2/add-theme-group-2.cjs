const fs = require('fs');
let c = fs.readFileSync('src/components/settings/AppearanceScreen.tsx', 'utf8');

if (!c.includes('<SettingGroup label="Theme">')) {
  c = c.replace(
    /<SettingGroup label="Accent color">/,
    `<SettingGroup label="Theme">
        <div className="grid grid-cols-2 gap-2 p-3 sm:grid-cols-4">
          {(Object.keys(THEMES) as ThemeId[]).map((id) => (
            <ThemeCard key={id} id={id} active={s.theme === id} onSelect={() => s.setTheme(id)} />
          ))}
        </div>
      </SettingGroup>
      <SettingGroup label="Accent color">`
  );
  fs.writeFileSync('src/components/settings/AppearanceScreen.tsx', c, 'utf8');
}
