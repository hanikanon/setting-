const fs = require('fs');
let c = fs.readFileSync('src/components/settings/AppearanceScreen.tsx', 'utf8');

c = c.replace(
  '    <>\n      <LivePreview />\n      \n      <SettingGroup label="Accent color">',
  '    <>\n      <LivePreview />\n      <SettingGroup label="Theme">\n        <div className="grid grid-cols-2 gap-2 p-3 sm:grid-cols-4">\n          {(Object.keys(THEMES) as ThemeId[]).map((id) => (\n            <ThemeCard key={id} id={id} active={s.theme === id} onSelect={() => s.setTheme(id)} />\n          ))}\n        </div>\n      </SettingGroup>\n      <SettingGroup label="Accent color">'
);

fs.writeFileSync('src/components/settings/AppearanceScreen.tsx', c, 'utf8');
