const fs = require('fs');
let c = fs.readFileSync('src/components/settings/AppearanceScreen.tsx', 'utf8');

c = `import { ChatPreview } from "./ChatPreview";\n` + c;

c = c.replace(
  /function LivePreview\(\) \{[\s\S]*?className="flex flex-col p-4 gap-4"[\s\S]*?<\/div>\n    <\/motion\.div>\n  \);\n\}/,
  `function LivePreview() {
  const s = useSettings();
  
  const fsMap: Record<string, string> = { small: "12.5px", medium: "14.5px", large: "16px", xl: "18px" };
  const fontSize = fsMap[s.fontSize] || "14.5px";
  
  return (
    <motion.div
      /* optimized out layout */
      initial={false}
      className="mx-4 mb-6 overflow-hidden border border-border/50 shadow-xl"
      style={{
        borderRadius: s.radius >= 20 ? 32 : s.radius + 12,
        height: 380,
      }}
    >
      <ChatPreview
        theme={s.theme}
        accent={s.accent}
        radius={s.radius}
        bubble={s.bubble}
        wallpaper={s.wallpaper}
        fontSize={fontSize}
        blur={s.blur}
        isCard={false}
      />
    </motion.div>
  );
}`
);

// We need to also remove `Bubble` function since it's not used anymore.
c = c.replace(/function Bubble\(\{[\s\S]*?\}\n\}/, '');

fs.writeFileSync('src/components/settings/AppearanceScreen.tsx', c, 'utf8');
