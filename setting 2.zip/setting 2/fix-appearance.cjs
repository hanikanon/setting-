const fs = require('fs');
let c = fs.readFileSync('src/components/settings/AppearanceScreen.tsx', 'utf8');

c = c.replace(/    <motion\.div\n      layout/g, '    <motion.div\n      /* optimized out layout */');

fs.writeFileSync('src/components/settings/AppearanceScreen.tsx', c, 'utf8');
