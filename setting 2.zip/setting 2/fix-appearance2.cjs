const fs = require('fs');
let c = fs.readFileSync('src/components/settings/AppearanceScreen.tsx', 'utf8');

// Remove Theme group from AppearanceScreen
c = c.replace(
  /<SettingGroup label="Theme">[\s\S]*?<\/SettingGroup>/,
  ''
);

fs.writeFileSync('src/components/settings/AppearanceScreen.tsx', c, 'utf8');
