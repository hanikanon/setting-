const fs = require('fs');
let c = fs.readFileSync('src/components/settings/AppearanceScreen.tsx', 'utf8');

const wallpaperGroupMatch = c.match(/<SettingGroup label="Wallpaper">[\s\S]*?<\/SettingGroup>/);
if (wallpaperGroupMatch) {
  c = c.replace(wallpaperGroupMatch[0], '');
  // Insert it after Accent color
  c = c.replace(
    /<\/SettingGroup>\s*<SettingGroup label="Chat bubbles">/,
    `</SettingGroup>\n\n      ${wallpaperGroupMatch[0]}\n\n      <SettingGroup label="Chat bubbles">`
  );
}

fs.writeFileSync('src/components/settings/AppearanceScreen.tsx', c, 'utf8');
