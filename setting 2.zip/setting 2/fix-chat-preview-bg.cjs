const fs = require('fs');
let c = fs.readFileSync('src/components/settings/ChatPreview.tsx', 'utf8');

c = c.replace(
  /background: \`\$\{WALLPAPERS\[wallpaper as keyof typeof WALLPAPERS\]\?\.value\}, \$\{t\.surface\}\`,/,
  'background: t.wallpaper || `${WALLPAPERS[wallpaper as keyof typeof WALLPAPERS]?.value}, ${t.surface}`,'
);

fs.writeFileSync('src/components/settings/ChatPreview.tsx', c, 'utf8');
