const fs = require('fs');
let c = fs.readFileSync('src/components/settings/ChatPreview.tsx', 'utf8');

c = c.replace(
  /<button className=\{`\$\{isCard \? 'w-6 h-6' : 'w-8 h-8'\}/g,
  '<div className={`flex-shrink-0 ${isCard ? "w-6 h-6" : "w-8 h-8"}'
);
c = c.replace(/<\/button>/g, '</div>');

fs.writeFileSync('src/components/settings/ChatPreview.tsx', c, 'utf8');
