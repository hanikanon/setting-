const fs = require('fs');
let c = fs.readFileSync('src/components/settings/ChatPreview.tsx', 'utf8');

c = c.replace(/<button/g, '<div');
c = c.replace(/<\/button>/g, '</div>');

fs.writeFileSync('src/components/settings/ChatPreview.tsx', c, 'utf8');
