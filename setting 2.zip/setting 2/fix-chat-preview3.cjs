const fs = require('fs');
let c = fs.readFileSync('src/components/settings/ChatPreview.tsx', 'utf8');

const appIconSvg = `
const CryptvoraAppIcon = ({ size = 32 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="100" height="100" rx="22" fill="#0A0A10" />
    <path d="M32 36 C12 36, 12 64, 32 64 C46 64, 50 50, 50 50 C50 50, 54 36, 68 36 C88 36, 88 64, 68 64 C54 64, 50 50, 50 50 C50 50, 46 36, 32 36 Z" fill="transparent" stroke="white" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
`;

if (!c.includes('CryptvoraAppIcon')) {
  c = c.replace(
    'type ChatPreviewProps',
    appIconSvg + '\n\ntype ChatPreviewProps'
  );
}

c = c.replace(
  '{/* Left Bubble - File */}',
  `{/* Left Bubble - App Icon */}
        <div className="flex justify-start">
          <div 
            className="flex flex-col gap-2 p-2.5 shadow-sm"
            style={{ 
              background: t.surface2, 
              borderRadius: getBubbleRadius("left"),
              maxWidth: "85%"
            }}
          >
            <div className="flex items-center gap-3">
              <CryptvoraAppIcon size={isCard ? 24 : 32} />
              <div className="flex flex-col">
                <span className={\`\${isCard ? 'text-[10px]' : 'text-[13px]'} font-bold\`} style={{ color: t.fg }}>Cryptvora</span>
                <span className={\`\${isCard ? 'text-[8px]' : 'text-[11px]'}\`} style={{ color: t.muted }}>v2.0 Premium</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Left Bubble - File */}`
);

fs.writeFileSync('src/components/settings/ChatPreview.tsx', c, 'utf8');
