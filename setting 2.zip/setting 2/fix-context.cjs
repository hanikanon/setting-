const fs = require("fs");
const path = require("path");
const p = path.join(__dirname, "src/components/settings/SettingsContext.tsx");
let code = fs.readFileSync(p, "utf8");

code = code.replace(
  `  const updateSocial = (platform: SocialPlatform, url: string | null) => {
    setProfile({
      ...profile,
      socials: (() => {
        const next = { ...profile.socials };
        if (!url) delete next[platform];
        else next[platform] = url;
        return next;
      })(),
    });
  };`,
  `  const updateSocial = useCallback((platform: SocialPlatform, url: string | null) => {
    setProfile((prev) => {
      const next = { ...prev.socials };
      if (!url) delete next[platform];
      else next[platform] = url;
      return { ...prev, socials: next };
    });
  }, []);`,
);

code = code.replace(
  `const setPref = <K extends keyof Prefs>(k: K, v: Prefs[K]) => setPrefs((p) => ({ ...p, [k]: v }));`,
  `const setPref = useCallback(<K extends keyof Prefs>(k: K, v: Prefs[K]) => setPrefs((p) => ({ ...p, [k]: v })), []);`,
);

code = code.replace(
  `const blockDevice = (d: BlockedDevice) =>\n    setBlockedDevices((prev) => (prev.some((x) => x.id === d.id) ? prev : [d, ...prev]));`,
  `const blockDevice = useCallback((d: BlockedDevice) => setBlockedDevices((prev) => (prev.some((x) => x.id === d.id) ? prev : [d, ...prev])), []);`,
);

code = code.replace(
  `const unblockDevice = (id: string) =>\n    setBlockedDevices((prev) => prev.filter((x) => x.id !== id));`,
  `const unblockDevice = useCallback((id: string) => setBlockedDevices((prev) => prev.filter((x) => x.id !== id)), []);`,
);

code = code.replace(
  `const addFolder = (f: ChatFolder) =>\n    setFolders((prev) => (prev.some((x) => x.id === f.id) ? prev : [...prev, f]));`,
  `const addFolder = useCallback((f: ChatFolder) => setFolders((prev) => (prev.some((x) => x.id === f.id) ? prev : [...prev, f])), []);`,
);

code = code.replace(
  `const renameFolder = (id: string, name: string) =>\n    setFolders((prev) => prev.map((x) => (x.id === id ? { ...x, name } : x)));`,
  `const renameFolder = useCallback((id: string, name: string) => setFolders((prev) => prev.map((x) => (x.id === id ? { ...x, name } : x))), []);`,
);

code = code.replace(
  `const removeFolder = (id: string) => setFolders((prev) => prev.filter((x) => x.id !== id));`,
  `const removeFolder = useCallback((id: string) => setFolders((prev) => prev.filter((x) => x.id !== id)), []);`,
);

code = code.replace(
  `const reorderFolders = (from: number, to: number) =>\n    setFolders((prev) => {\n      const next = [...prev];\n      const [m] = next.splice(from, 1);\n      next.splice(to, 0, m);\n      return next;\n    });`,
  `const reorderFolders = useCallback((from: number, to: number) => {\n    setFolders((prev) => {\n      const next = [...prev];\n      const [m] = next.splice(from, 1);\n      next.splice(to, 0, m);\n      return next;\n    });\n  }, []);`,
);

if (!code.includes("useCallback")) {
  code = code.replace("useState, useMemo", "useState, useMemo, useCallback");
  code = code.replace("useContext, useMemo", "useContext, useMemo, useCallback");
  code = code.replace("import { useState", "import { useCallback, useState");
}

fs.writeFileSync(p, code, "utf8");
console.log("done");
