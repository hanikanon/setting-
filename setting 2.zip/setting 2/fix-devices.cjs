const fs = require("fs");
const path = require("path");
const file = path.join(__dirname, "src/routes/settings.devices.tsx");
let code = fs.readFileSync(file, "utf8");

// Replace header
const oldHeader = `<div className="flex flex-col items-center px-6 pb-6 pt-8 text-center">
        <span
          className="mb-4 flex h-[72px] w-[72px] items-center justify-center rounded-[24px]"
          style={{ background: "color-mix(in oklab, var(--primary) 12%, transparent)" }}
        >
          <Smartphone size={36} className="text-[var(--primary)]" />
        </span>
        <h2 className="mb-2 text-[20px] font-bold text-foreground">Your devices</h2>
        <p className="text-[14px] leading-relaxed text-muted-foreground">
          You are currently logged in to Cryptvora on these devices. You can link new devices or
          revoke access to any existing sessions.
        </p>
      </div>`;

const newHeader = `<div className="flex flex-col items-center px-6 pb-6 pt-8 text-center">
        <div className="mb-4 text-[72px] leading-none drop-shadow-2xl">
          💻
        </div>
        <p className="text-[13.5px] leading-relaxed text-muted-foreground mt-2">
          Log in to Telegram Desktop or Telegram<br/>Web via QR code.
        </p>
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => navigate({ to: "/settings/qr" })}
          className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl py-3.5 text-[15px] font-semibold text-white shadow-lg shadow-black/10 transition-transform"
          style={{ background: "var(--gradient-brand)" }}
        >
          Link Desktop Device <QrCode size={18} />
        </motion.button>
      </div>`;
code = code.replace(oldHeader, newHeader);

const terminateOld = `<div className="mt-4 px-3 pb-3">
            <motion.button
              whileTap={{ scale: 0.97 }}
              onClick={() => setConfirmTerminateAll(true)}
              className="flex w-full items-center justify-center gap-2 rounded-xl border border-destructive/20 py-3 text-[14.5px] font-semibold text-destructive hover:bg-destructive/10"
            >
              <LogOut size={16} />
              Terminate all other sessions
            </motion.button>
          </div>`;

const terminateNew = `<div className="mt-2 px-3 pb-3">
            <motion.button
              whileTap={{ scale: 0.97 }}
              onClick={() => setConfirmTerminateAll(true)}
              className="flex w-full items-center justify-center gap-2 rounded-xl py-3 text-[14.5px] font-semibold text-destructive hover:bg-destructive/10"
            >
              Terminate All Other Sessions <span className="text-[18px]">✋</span>
            </motion.button>
            <p className="text-center text-[12px] text-muted-foreground mt-1">Logs out all devices except for this one.</p>
          </div>`;
code = code.replace(terminateOld, terminateNew);
code = code.replace("import { Smartphone }", "import { Smartphone, QrCode }");

fs.writeFileSync(file, code, "utf8");
console.log("done devices");
