const fs = require("fs");
const path = require("path");
const file = path.join(__dirname, "src/routes/settings.folders.tsx");
let code = fs.readFileSync(file, "utf8");

const oldHeader = `<div className="flex flex-col items-center px-6 pb-6 pt-8 text-center">
        <span
          className="mb-4 flex h-[72px] w-[72px] items-center justify-center rounded-[24px]"
          style={{ background: "var(--gradient-brand)" }}
        >
          <FolderOpen size={36} className="text-white" />
        </span>
        <h2 className="mb-2 text-[20px] font-bold text-foreground">Chat Folders</h2>
        <p className="text-[14px] leading-relaxed text-muted-foreground">
          Create folders to organize your chats and quickly switch between them.
        </p>
      </div>`;

const newHeader = `<div className="flex flex-col items-center px-6 pb-6 pt-8 text-center">
        <div className="mb-4 text-[72px] leading-none drop-shadow-2xl">
          🗂️
        </div>
        <p className="text-[13.5px] leading-relaxed text-muted-foreground mt-2">
          Create folders for different groups of chats and<br/>quickly switch between them.
        </p>
      </div>`;

code = code.replace(oldHeader, newHeader);

const oldCreate = `<motion.button
          whileTap={{ scale: 0.99 }}
          onClick={() => setCreating(true)}
          className="flex w-full items-center gap-3 border-t border-border px-4 py-3 text-left"
        >
          <span
            className="flex h-10 w-10 items-center justify-center rounded-xl text-white"
            style={{ background: "var(--gradient-brand)" }}
          >
            <Plus size={18} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[14.5px] font-semibold text-[var(--primary)]">Create new folder</p>
            <p className="text-[12px] text-muted-foreground">Group chats by topic or people</p>
          </div>
          <FolderPlus size={16} className="text-muted-foreground" />
        </motion.button>`;

const newCreate = `<motion.button
          whileTap={{ scale: 0.99 }}
          onClick={() => setCreating(true)}
          className="flex w-full items-center justify-between gap-3 border-t border-border/40 px-4 py-3 text-left"
        >
          <span className="text-[14.5px] font-medium text-[var(--primary)]">Create New Folder</span>
          <span
            className="flex h-6 w-6 items-center justify-center rounded-full text-white"
            style={{ background: "var(--primary)" }}
          >
            <Plus size={16} />
          </span>
        </motion.button>`;

code = code.replace(oldCreate, newCreate);

code = code.replace(
  `{f.id === "all" ? "All your chats" : "Tap to edit"}`,
  `{f.id === "all" ? "" : "Tap to edit"}`,
);

const oldTags = `<RowToggle
          icon={Tag}
          label="Show folder tags"
          description="Display folder name next to each chat"
          checked={prefs.showFolderTags}
          onChange={(v) => setPref("showFolderTags", v)}
          last
        />`;

const newTags = `<SettingItem
          icon={Lock}
          label="Show Folder Tags"
          showArrow={false}
          trailing={<Toggle checked={prefs.showFolderTags} onChange={(v) => setPref("showFolderTags", v)} label="Show Folder Tags" />}
          last
        />
      </SettingGroup>
      <p className="px-5 text-center text-[12.5px] text-muted-foreground mt-[-10px] mb-8">
        Subscribe to <strong className="text-foreground">Telegram Premium</strong> to display folder names for each chat in the chat list.
      </p>`;

code = code.replace(oldTags, newTags);
if (!code.includes("import { Lock }")) {
  code = code.replace("import { Check", "import { Check, Lock");
  code = code.replace(
    'import { SettingGroup } from "@/components/settings/SettingGroup";',
    'import { SettingGroup } from "@/components/settings/SettingGroup";\nimport { SettingItem } from "@/components/settings/SettingItem";\nimport { Toggle } from "@/components/settings/Toggle";',
  );
}

fs.writeFileSync(file, code, "utf8");
console.log("done folders");
