const fs = require('fs');
let c = fs.readFileSync('src/routes/index.tsx', 'utf8');

c = c.replace(
  /initial=\{\{ opacity: 0, y: -8 \}\}/g,
  `initial={false}`
);
c = c.replace(
  /initial=\{\{ opacity: 0, y: 6 \}\}/g,
  `initial={false}`
);

fs.writeFileSync('src/routes/index.tsx', c, 'utf8');
