const fs = require('fs');

let content = fs.readFileSync('src/routes/index.tsx', 'utf8');

content = content.replace('  Palette,\n', '  Palette,\n  Brush,\n');

const newRoute = `  {
    path: "/settings/themes",
    label: "Browse Themes",
    description: "Explore color themes gallery",
    icon: Brush,
    group: "Experience",
  },
  {
    path: "/settings/appearance",`;

content = content.replace('  {\n    path: "/settings/appearance",', newRoute);

fs.writeFileSync('src/routes/index.tsx', content, 'utf8');
