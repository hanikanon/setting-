const fs = require('fs');

let content = fs.readFileSync('src/components/settings/AppearanceScreen.tsx', 'utf8');

const oldLivePreview = `function LivePreview() {
  const s = useSettings();
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="mx-3 mb-6 overflow-hidden rounded-3xl border border-border bg-surface/70 backdrop-blur-xl"
      style={{
        background: \`\${WALLPAPERS[s.wallpaper].value}, var(--surface)\`,
      }}
    >
      <div className="flex items-center gap-2 border-b border-border px-4 py-2.5">
        <div
          className="flex h-7 w-7 items-center justify-center rounded-full text-[11px] font-semibold text-white"
          style={{ background: "var(--gradient-brand)" }}
        >
          CV
        </div>
        <div className="flex-1">
          <p className="text-[12.5px] font-semibold text-foreground">Live preview</p>
          <p className="text-[11px] text-muted-foreground">Changes apply instantly</p>
        </div>
      </div>
      <div className="space-y-2 p-4">
        <Bubble side="left" text="How's the BTC trade going? 📈" bubble={s.bubble} />
        <Bubble side="right" text="Up 4.2% — moved the stop to entry." bubble={s.bubble} />
        <Bubble side="left" text="Beautiful. Ping when you exit." bubble={s.bubble} />
      </div>
    </motion.div>
  );
}`;

const newLivePreview = `function LivePreview() {
  const s = useSettings();
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="mx-3 mb-6 overflow-hidden border border-border bg-surface/70 backdrop-blur-xl"
      style={{
        borderRadius: s.radius >= 20 ? 28 : s.radius + 8,
        background: \`\${WALLPAPERS[s.wallpaper].value}, var(--surface)\`,
      }}
    >
      <div className="flex items-center gap-2 border-b border-border px-4 py-2.5 bg-[color-mix(in_oklab,var(--surface-2)_40%,transparent)]">
        <div
          className="flex h-7 w-7 items-center justify-center rounded-full text-[11px] font-semibold text-white"
          style={{ background: "var(--gradient-brand)" }}
        >
          CV
        </div>
        <div className="flex-1">
          <p className="text-[12.5px] font-semibold text-foreground">Live preview</p>
          <p className="text-[11px] text-muted-foreground">Changes apply instantly</p>
        </div>
      </div>

      <div className="flex flex-col p-4 gap-4">
        {/* Card */}
        <div 
          className="p-3 border border-border shadow-sm flex items-center justify-between"
          style={{ 
             borderRadius: s.radius,
             background: "var(--surface-2)" 
          }}
        >
           <div className="flex flex-col">
             <span className="text-[13px] font-medium text-foreground">System update</span>
             <span className="text-[11px] text-muted-foreground">Version 2.0 is available</span>
           </div>
           <div className="w-10 h-6 flex items-center p-1" style={{ borderRadius: s.radius, background: "var(--primary-soft)" }}>
              <div className="w-4 h-4 rounded-full ml-auto" style={{ background: "var(--primary)" }} />
           </div>
        </div>
        
        {/* Bubble */}
        <Bubble side="right" text="Looks great! ✨" bubble={s.bubble} />

        {/* Input & Button */}
        <div className="flex gap-2 items-center mt-1">
           <input 
             disabled
             placeholder="Message..." 
             className="flex-1 px-3.5 py-2.5 text-[12.5px] border border-border placeholder:text-muted-foreground text-foreground outline-none"
             style={{ 
                borderRadius: s.radius,
                background: "var(--background)"
             }}
           />
           <button 
             className="px-4 py-2.5 text-[13px] font-semibold text-white transition-opacity flex items-center justify-center"
             style={{ 
                borderRadius: s.radius,
                background: "var(--gradient-brand, var(--primary))",
                boxShadow: "0 2px 10px -2px color-mix(in oklab, var(--primary) 50%, transparent)"
             }}
           >
             Send
           </button>
        </div>
      </div>
    </motion.div>
  );
}`;

content = content.replace(oldLivePreview, newLivePreview);
fs.writeFileSync('src/components/settings/AppearanceScreen.tsx', content, 'utf8');
