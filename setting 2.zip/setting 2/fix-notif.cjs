const fs = require("fs");
const path = require("path");
const file = path.join(__dirname, "src/routes/settings.notifications.tsx");
let code = fs.readFileSync(file, "utf8");

code = code.replace(
  `import { SettingGroup } from "@/components/settings/SettingGroup";`,
  `import { SettingGroup } from "@/components/settings/SettingGroup";\nimport { SettingItem } from "@/components/settings/SettingItem";`,
);

const oldChatNotifs = `<SettingGroup label="Notifications for chats">
        <RowToggle
          icon={User}
          label="Private chats"
          checked={prefs.notifPrivateChats}
          onChange={(v) => setPref("notifPrivateChats", v)}
        />
        <RowToggle
          icon={Users2}
          label="Group activity"
          description="Reactions, joins & mentions"
          checked={prefs.notifGroupsDetail}
          onChange={(v) => setPref("notifGroupsDetail", v)}
        />
        <RowToggle
          icon={Megaphone}
          label="Channel posts"
          checked={prefs.notifChannelsDetail}
          onChange={(v) => setPref("notifChannelsDetail", v)}
        />
        <RowToggle
          icon={PlayCircle}
          label="Stories"
          checked={prefs.notifStories}
          onChange={(v) => setPref("notifStories", v)}
        />
        <RowToggle
          icon={Heart}
          label="Reactions"
          description="Messages & stories"
          checked={prefs.notifReactions}
          onChange={(v) => setPref("notifReactions", v)}
          last
        />
      </SettingGroup>`;

const newChatNotifs = `<SettingGroup label="Notifications for chats">
        <RowToggle
          icon={User}
          label="Private Chats"
          description="Tap to change"
          checked={prefs.notifPrivateChats}
          onChange={(v) => setPref("notifPrivateChats", v)}
        />
        <RowToggle
          icon={Users}
          label="Groups"
          description="On, 1 exceptions"
          checked={prefs.notifGroupsDetail}
          onChange={(v) => setPref("notifGroupsDetail", v)}
        />
        <RowToggle
          icon={Megaphone}
          label="Channels"
          description="On, 1 exception"
          checked={prefs.notifChannelsDetail}
          onChange={(v) => setPref("notifChannelsDetail", v)}
        />
        <RowToggle
          icon={PlayCircle}
          label="Stories"
          description="Off, 1 exceptions"
          checked={prefs.notifStories}
          onChange={(v) => setPref("notifStories", v)}
        />
        <RowToggle
          icon={Heart}
          label="Reactions"
          description="Messages, Stories"
          checked={prefs.notifReactions}
          onChange={(v) => setPref("notifReactions", v)}
          last
        />
      </SettingGroup>`;

code = code.replace(oldChatNotifs, newChatNotifs);

const oldInApp = `<SettingGroup label="In-app">
        <RowToggle
          icon={Volume2}
          label="Sounds"
          checked={prefs.inAppSounds}
          onChange={(v) => {
            setPref("inAppSounds", v);
            if (v) {
              void playNotificationSound();
              toast.success("Sound enabled — playing preview");
            }
          }}
        />
        <RowToggle
          icon={Vibrate}
          label="Vibrate"
          checked={prefs.vibrate}
          onChange={(v) => {
            setPref("vibrate", v);
            if (v) {
              const ok = vibrateDevice([40, 30, 90]);
              toast.success(ok ? "Vibration enabled" : "Vibration not supported on this device");
            }
          }}
        />
        <RowToggle
          icon={Bell}
          label="Show message preview"
          description="Display sender & content in banners"
          checked={prefs.notificationPreview}
          onChange={(v) => setPref("notificationPreview", v)}
          last
        />
      </SettingGroup>`;

const newInApp = `<SettingGroup label="Voice calls">
        <SettingItem
          label="Vibrate"
          trailing={<span className="text-[14px] text-foreground font-medium">Default</span>}
        />
        <SettingItem
          label="Ringtone"
          trailing={<span className="text-[14px] text-foreground font-medium">Default</span>}
          last
        />
      </SettingGroup>
      
      <SettingGroup label="Badge Counter">
        <RowToggle
          icon={Badge}
          label="Enabled"
          checked={prefs.badgeCounter}
          onChange={(v) => setPref("badgeCounter", v)}
          last
        />
      </SettingGroup>`;

code = code.replace(oldInApp, newInApp);

const badgeGroup = `<SettingGroup label="Badge counter">
        <RowToggle
          icon={Badge}
          label="Show badge counter"
          description="Unread count on the app icon"
          checked={prefs.badgeCounter}
          onChange={(v) => setPref("badgeCounter", v)}
          last
        />
      </SettingGroup>`;

code = code.replace(badgeGroup, ``);

fs.writeFileSync(file, code, "utf8");
console.log("done notif");
