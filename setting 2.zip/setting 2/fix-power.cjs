const fs = require("fs");
const path = require("path");
const file = path.join(__dirname, "src/routes/settings.power.tsx");
let code = fs.readFileSync(file, "utf8");

// Replace "Animated stickers" to "Animated Stickers" and add fraction
code = code.replace(
  `label="Animated stickers"`,
  `label="Animated Stickers" trailing={<span className="text-[12px] text-muted-foreground mr-1 flex items-center gap-1"><span className="opacity-60">2/2</span> <ChevronDown size={14}/></span>}`,
);
code = code.replace(
  `label="Animated emoji"`,
  `label="Animated Emoji" trailing={<span className="text-[12px] text-muted-foreground mr-1 flex items-center gap-1"><span className="opacity-60">1/3</span> <ChevronDown size={14}/></span>}`,
);
code = code.replace(
  `label="Chat effects"`,
  `label="Animations in Chats" trailing={<span className="text-[12px] text-muted-foreground mr-1 flex items-center gap-1"><span className="opacity-60">2/6</span> <ChevronDown size={14}/></span>}`,
);
code = code.replace(`label="Animations in calls"`, `label="Animations in Calls"`);
code = code.replace(`label="Autoplay videos"`, `label="Autoplay Videos"`);
code = code.replace(`label="Autoplay GIFs"`, `label="Autoplay GIFs"`);
code = code.replace(`label="Particles"`, `label="Particles"`);
code = code.replace(`label="Enable smooth transitions"`, `label="Enable Smooth Transitions"`);
code = code.replace(
  `import { Sticker, Wand2, Zap, } from "lucide-react";`,
  `import { Sticker, Wand2, Zap, ChevronDown } from "lucide-react";`,
);

if (!code.includes("ChevronDown")) {
  code = code.replace(
    "import { SettingsScreen }",
    'import { ChevronDown } from "lucide-react";\nimport { SettingsScreen }',
  );
}

fs.writeFileSync(file, code, "utf8");
console.log("done power");
