const fs = require("fs");
const path = require("path");
const file = path.join(__dirname, "src/routes/settings.folders.tsx");
let code = fs.readFileSync(file, "utf8");

code = code.replace(/<\/SettingGroup>/g, "");

const insertAfter = (str, search, insert) => str.replace(search, search + insert);

code = insertAfter(
  code,
  `toast.success(\`\${f.name} added\`);
                }}
                className="rounded-full px-3 py-1.5 text-[12.5px] font-semibold text-[var(--primary-foreground)]"
                style={{ background: "var(--gradient-brand)" }}
              >
                Add
              </motion.button>
            </div>
          ))}
`,
  `        </SettingGroup>\n`,
);

code = insertAfter(
  code,
  `        <motion.button
          whileTap={{ scale: 0.99 }}
          onClick={() => setCreating(true)}
          className="flex w-full items-center justify-between gap-3 border-t border-border/40 px-4 py-3 text-left"
        >
          <span className="text-[14.5px] font-medium text-[var(--primary)]">Create New Folder</span>
          <span
            className="flex h-6 w-6 items-center justify-center rounded-full text-white"
            style={{ background: "var(--primary)" }}
          >
            <Plus size={16} />
          </span>
        </motion.button>
`,
  `      </SettingGroup>\n`,
);

code = insertAfter(
  code,
  `      <SettingGroup label="Display">
        <SettingItem
          icon={Lock}
          label="Show Folder Tags"
          showArrow={false}
          trailing={<Toggle checked={prefs.showFolderTags} onChange={(v) => setPref("showFolderTags", v)} label="Show Folder Tags" />}
          last
        />
`,
  `      </SettingGroup>\n`,
);

fs.writeFileSync(file, code, "utf8");
console.log("done rebuild");
