const fs = require("fs");
const path = require("path");
const file = path.join(__dirname, "src/routes/settings.folders.tsx");
let code = fs.readFileSync(file, "utf8");

code = code.replace(
  `            </div>          ))}        `,
  `            </div>          ))}        </SettingGroup>`,
);

code = code.replace(
  `          </span>        </motion.button>      `,
  `          </span>        </motion.button>      </SettingGroup>`,
);

code = code.replace(
  `          last        />      `,
  `          last        />      </SettingGroup>`,
);

fs.writeFileSync(file, code, "utf8");
console.log("restored");
