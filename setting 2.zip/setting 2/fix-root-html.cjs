const fs = require('fs');
let c = fs.readFileSync('src/routes/__root.tsx', 'utf8');

c = c.replace(
  '      <body>',
  `      <body>
        <div id="ssr-loader" style={{ position: 'fixed', inset: 0, backgroundColor: 'oklch(0.11 0.006 280)', zIndex: 999999, transition: 'opacity 0.3s ease-out' }}></div>
        <script dangerouslySetInnerHTML={{ __html: \`
          if (typeof window !== 'undefined') {
            window.addEventListener('load', () => {
              const l = document.getElementById('ssr-loader');
              if(l) { l.style.opacity = '0'; setTimeout(() => l.remove(), 300); }
            });
          }
        \`}} />`
);

fs.writeFileSync('src/routes/__root.tsx', c, 'utf8');
