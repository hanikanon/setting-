const fs = require('fs');
let c = fs.readFileSync('src/routes/__root.tsx', 'utf8');

c = c.replace(
  'function ThemedShell({ children }: { children: ReactNode }) {',
  `import { useLayoutEffect } from "react";
const useIsomorphicLayoutEffect = typeof window !== 'undefined' ? useLayoutEffect : useEffect;

function ThemedShell({ children }: { children: ReactNode }) {
  useIsomorphicLayoutEffect(() => {
    const l = document.getElementById('ssr-loader');
    if(l) { l.style.opacity = '0'; setTimeout(() => l.remove(), 300); }
  }, []);`
);

// We can also remove the window.onload script to avoid conflict
c = c.replace(
  /window\.addEventListener\('load', \(\) => \{[\s\S]*?\}\);/g,
  ''
);

fs.writeFileSync('src/routes/__root.tsx', c, 'utf8');
