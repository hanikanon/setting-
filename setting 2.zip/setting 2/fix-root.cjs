const fs = require('fs');
let c = fs.readFileSync('src/routes/__root.tsx', 'utf8');

c = c.replace(
  'import { SettingsProvider, themeStyle, useSettings } from "../components/settings/SettingsContext";',
  `import { SettingsProvider, themeStyle, useSettings } from "../components/settings/SettingsContext";\nimport { AnimatePresence, motion } from "framer-motion";\nimport { useRouterState } from "@tanstack/react-router";`
);

c = c.replace(
  '          <Outlet />',
  `          <RouteTransition>
            <Outlet />
          </RouteTransition>`
);

c += `

function RouteTransition({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const s = useSettings();
  const speed = s.motion === "fast" ? 0.14 : s.motion === "reduced" ? 0 : 0.24;
  
  return (
    <AnimatePresence mode="popLayout" initial={false}>
      <motion.div
        key={pathname}
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 1.04 }}
        transition={{ duration: speed, ease: [0.16, 1, 0.3, 1] }}
        className="w-full h-full"
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}
`;

fs.writeFileSync('src/routes/__root.tsx', c, 'utf8');
