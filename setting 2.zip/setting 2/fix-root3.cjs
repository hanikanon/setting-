const fs = require('fs');
let c = fs.readFileSync('src/routes/__root.tsx', 'utf8');

// Remove duplicate imports
c = c.replace(/import \{ useLayoutEffect \} from "react";\nconst useIsomorphicLayoutEffect = typeof window !== 'undefined' \? useLayoutEffect : useEffect;\n/g, '');

// Add it to top
c = c.replace('import { useEffect, type ReactNode } from "react";', 'import { useEffect, useLayoutEffect, type ReactNode } from "react";\nconst useIsomorphicLayoutEffect = typeof window !== "undefined" ? useLayoutEffect : useEffect;');

fs.writeFileSync('src/routes/__root.tsx', c, 'utf8');
