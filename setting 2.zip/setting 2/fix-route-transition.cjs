const fs = require('fs');
let c = fs.readFileSync('src/routes/__root.tsx', 'utf8');

c = c.replace(
  '      <motion.div\n        key={pathname}\n        initial={{ opacity: 0, scale: 0.96 }}\n        animate={{ opacity: 1, scale: 1 }}\n        exit={{ opacity: 0, scale: 1.04 }}\n        transition={{ duration: speed, ease: [0.16, 1, 0.3, 1] }}\n        className="w-full h-full"\n      >\n        {children}\n      </motion.div>',
  `      <motion.div
        key={pathname}
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 1.04 }}
        transition={{ duration: speed, ease: [0.16, 1, 0.3, 1] }}
        style={{ width: '100%', height: '100%', position: 'absolute', top: 0, left: 0 }}
      >
        {children}
      </motion.div>`
);

c = c.replace(
  /function ThemedShell\(\{ children \}: \{ children: ReactNode \}\) \{[\s\S]*?className="min-h-svh w-full"[\s\S]*?className="min-h-svh w-full"/,
  `import { useLayoutEffect } from "react";
const useIsomorphicLayoutEffect = typeof window !== 'undefined' ? useLayoutEffect : useEffect;

function ThemedShell({ children }: { children: ReactNode }) {
  const s = useSettings();
  const style = themeStyle(s.theme, s.accent, s.radius, s.fontSize, s.blur);
  useIsomorphicLayoutEffect(() => {
    const l = document.getElementById('ssr-loader');
    if(l) { l.style.opacity = '0'; setTimeout(() => l.remove(), 300); }
  }, []);
  
  return (
    <div style={style} className="min-h-svh w-full relative overflow-hidden">
      <div
        className="min-h-svh w-full relative"
`
);

fs.writeFileSync('src/routes/__root.tsx', c, 'utf8');
