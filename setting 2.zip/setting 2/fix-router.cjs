const fs = require('fs');
let c = fs.readFileSync('src/router.tsx', 'utf8');
c = c.replace('defaultPreloadStaleTime: 0,', 'defaultPreload: "intent",\n    defaultPreloadDelay: 50,\n    defaultPreloadStaleTime: 0,');
fs.writeFileSync('src/router.tsx', c, 'utf8');
