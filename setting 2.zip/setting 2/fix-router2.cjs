const fs = require('fs');
let c = fs.readFileSync('src/router.tsx', 'utf8');

if (!c.includes('SettingsSkeleton')) {
  c = 'import { SettingsSkeleton } from "./components/settings/SettingsSkeleton";\n' + c;
}

c = c.replace(
  'defaultPreloadStaleTime: 0,',
  `defaultPreloadStaleTime: 0,\n    defaultPendingComponent: SettingsSkeleton,`
);

fs.writeFileSync('src/router.tsx', c, 'utf8');
