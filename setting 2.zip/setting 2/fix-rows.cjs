const fs = require("fs");
const path = require("path");
const file = path.join(__dirname, "src/components/settings/rows.tsx");
let code = fs.readFileSync(file, "utf8");

code = code.replace(
  `last?: boolean;\n  }) {`,
  `last?: boolean;\n    trailing?: ReactNode;\n  }) {`,
);

code = code.replace(
  `trailing={<Toggle checked={checked} onChange={onChange} label={label} />}`,
  `trailing={<div className="flex items-center gap-1.5">{trailing}<Toggle checked={checked} onChange={onChange} label={label} /></div>}`,
);

fs.writeFileSync(file, code, "utf8");
console.log("done rows");
