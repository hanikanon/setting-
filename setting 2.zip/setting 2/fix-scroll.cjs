const fs = require('fs');
let c = fs.readFileSync('src/routes/__root.tsx', 'utf8');

c = c.replace(
  /style=\{\{ width: '100%', height: '100%', position: 'absolute', top: 0, left: 0 \}\}/,
  `style={{ width: '100%', height: '100%', position: 'absolute', top: 0, left: 0, overflowY: 'auto', overflowX: 'hidden', WebkitOverflowScrolling: 'touch' }}`
);

// We need to make sure the parent container takes exactly the screen height so the absolute child fits perfectly.
// Currently it is min-h-svh, let's change to h-svh to prevent body scrolling.
c = c.replace(
  /className="min-h-svh w-full relative overflow-hidden"/g,
  `className="h-svh w-full relative overflow-hidden"`
);

c = c.replace(
  /className="min-h-svh w-full relative"/g,
  `className="h-svh w-full relative"`
);

fs.writeFileSync('src/routes/__root.tsx', c, 'utf8');
