const fs = require('fs');
let c = fs.readFileSync('src/components/settings/AppearanceScreen.tsx', 'utf8');

c = c.replace(
  /<motion\.span\n\s*layoutId="seg"[\s\S]*?<\/motion\.span>/g,
  ''
);

c = c.replace(
  /{options\.map\(\(o\) => \{/g,
  `{/* The sliding background */}
        <motion.div
          className="absolute top-1 bottom-1 w-[calc(33.333%-0.25rem)] rounded-xl"
          initial={false}
          animate={{
            x: \`calc(\${options.findIndex(o => o.id === value) * 100}% + \${options.findIndex(o => o.id === value) * 4}px)\`
          }}
          transition={{ type: "spring", stiffness: 500, damping: 40 }}
          style={{
            background: "var(--gradient-brand)",
            boxShadow: "0 8px 20px -8px color-mix(in oklab, var(--primary) 50%, transparent)",
            zIndex: 0
          }}
        />
        {options.map((o) => {`
);

fs.writeFileSync('src/components/settings/AppearanceScreen.tsx', c, 'utf8');
