const fs = require('fs');
let c = fs.readFileSync('src/components/settings/SettingsScreen.tsx', 'utf8');

c = c.replace(
  /<AnimatePresence mode="wait">\s*<motion\.div[\s\S]*?key=\{title\}[\s\S]*?initial=\{[^}]+\}[\s\S]*?animate=\{[^}]+\}[\s\S]*?exit=\{[^}]+\}[\s\S]*?transition=\{[^}]+\}\s*>\s*\{children\}\s*<\/motion\.div>\s*<\/AnimatePresence>/,
  `{children}`
);

// We should also ensure the header doesn't start at opacity 0 on SSR.
c = c.replace(
  /initial=\{\{ opacity: 0, y: -8 \}\}/g,
  `initial={false}`
);
c = c.replace(
  /initial=\{\{ opacity: 0, x: -6 \}\}/g,
  `initial={false}`
);
c = c.replace(
  /initial=\{\{ opacity: 0, y: 4 \}\}/g,
  `initial={false}`
);

fs.writeFileSync('src/components/settings/SettingsScreen.tsx', c, 'utf8');
