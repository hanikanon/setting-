const fs = require("fs");
const path = require("path");

// 1. Update SettingItem.tsx
const p1 = path.join(__dirname, "src/components/settings/SettingItem.tsx");
let c1 = fs.readFileSync(p1, "utf8");
c1 = c1.replace(
  `!last ? "border-b border-border" : ""`,
  `!last ? "border-b border-border/40" : ""`,
);
fs.writeFileSync(p1, c1, "utf8");

// 2. Update rows.tsx
const p2 = path.join(__dirname, "src/components/settings/rows.tsx");
let c2 = fs.readFileSync(p2, "utf8");
c2 = c2.replace(
  `i !== options.length - 1 ? "border-b border-border" : ""`,
  `i !== options.length - 1 ? "border-b border-border/40" : ""`,
);
fs.writeFileSync(p2, c2, "utf8");

// 3. Update settings.notifications.tsx
const p3 = path.join(__dirname, "src/routes/settings.notifications.tsx");
let c3 = fs.readFileSync(p3, "utf8");
c3 = c3.replace(
  `<SettingGroup label="Show notifications for">`,
  `<SettingGroup label="Show notifications for" footer="Turn this off if you want to receive notifications only from your active account.">`,
);
c3 = c3.replace(
  `<SettingGroup label="Digest">`,
  `<SettingGroup label="Digest" footer="Quiet hours will automatically mute all notifications during the specified time.">`,
);
fs.writeFileSync(p3, c3, "utf8");

// 4. Update settings.power.tsx
const p4 = path.join(__dirname, "src/routes/settings.power.tsx");
let c4 = fs.readFileSync(p4, "utf8");
c4 = c4.replace(
  `<SettingGroup label="Low power mode">`,
  `<SettingGroup label="Low power mode" footer="Automatically reduce power usage and animations when your battery is below 10%.">`,
);
c4 = c4.replace(
  `<SettingGroup label="Power saving options">`,
  `<SettingGroup label="Power saving options" footer="You can disable animated transitions between different sections of the app.">`,
);
fs.writeFileSync(p4, c4, "utf8");

console.log("done");
