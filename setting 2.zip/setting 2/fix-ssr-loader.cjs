const fs = require('fs');
let c = fs.readFileSync('src/routes/__root.tsx', 'utf8');

const loaderHTML = `
<div id="ssr-loader" style={{ position: 'fixed', inset: 0, backgroundColor: 'oklch(0.11 0.006 280)', zIndex: 999999, transition: 'opacity 0.4s ease-out', pointerEvents: 'none', display: 'flex', justifyContent: 'center' }}>
  <div style={{ width: '100%', maxWidth: '560px', padding: '16px', display: 'flex', flexDirection: 'column', gap: '24px' }}>
    <div style={{ height: '36px', width: '36px', borderRadius: '12px', background: 'oklch(0.18 0.007 280)', opacity: 0.5 }} />
    <div style={{ height: '60px', width: '100%', borderRadius: '16px', background: 'oklch(0.145 0.007 280)', opacity: 0.5 }} />
    <div style={{ height: '300px', width: '100%', borderRadius: '24px', background: 'oklch(0.145 0.007 280)', opacity: 0.5 }} />
  </div>
</div>
`;

c = c.replace(
  /<div id="ssr-loader" style=\{\{ position: 'fixed', inset: 0, backgroundColor: 'oklch\(0\.11 0\.006 280\)', zIndex: 999999, transition: 'opacity 0\.3s ease-out' \}\}><\/div>/g,
  loaderHTML
);

fs.writeFileSync('src/routes/__root.tsx', c, 'utf8');
