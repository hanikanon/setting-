const fs = require('fs');
let c = fs.readFileSync('src/components/settings/ThemesScreen.tsx', 'utf8');

c = c.replace(/bubble: 'ios'/g, "bubble: 'tail'");

fs.writeFileSync('src/components/settings/ThemesScreen.tsx', c, 'utf8');
