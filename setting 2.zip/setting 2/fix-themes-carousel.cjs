const fs = require('fs');

const content = `import { ChatPreview } from "./ChatPreview";
import React, { useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { THEMES, type ThemeId, useSettings } from "./SettingsContext";

export function ThemesScreen() {
  const s = useSettings();
  const containerRef = useRef<HTMLDivElement>(null);

  return (
    <div className="flex flex-col h-[calc(100vh-64px)] overflow-hidden">
      <div className="flex-1 py-8 overflow-y-hidden overflow-x-auto hide-scrollbar">
        <div 
          ref={containerRef}
          className="flex gap-8 px-8 h-full items-center w-max snap-x snap-mandatory"
          style={{ scrollbarWidth: 'none', WebkitOverflowScrolling: 'touch' }}
        >
          {(Object.keys(THEMES) as ThemeId[]).map((id) => (
            <ThemeGalleryCard 
              key={id} 
              id={id} 
              active={s.theme === id} 
              onSelect={() => s.setTheme(id)} 
              accent={s.accent}
              radius={s.radius}
              bubble={s.bubble}
              wallpaper={s.wallpaper}
              fontSize="14.5px"
              blur={s.blur}
            />
          ))}
        </div>
      </div>
      
      <div className="p-6 text-center border-t border-[var(--border)] bg-[var(--surface)] shrink-0">
         <h2 className="text-xl font-bold mb-2">Premium Gallery</h2>
         <p className="text-[14px] text-[var(--muted-foreground)] max-w-sm mx-auto">
           Instantly preview how Cryptvora transforms with every theme. Your chat interface adapts dynamically to match your style.
         </p>
      </div>
    </div>
  );
}

const ThemeGalleryCard = React.memo(
  function ThemeGalleryCard({
    id,
    active,
    onSelect,
    accent,
    radius,
    bubble,
    wallpaper,
    fontSize,
    blur,
  }: {
    id: ThemeId;
    accent: any;
    radius: number;
    bubble: any;
    wallpaper: string;
    fontSize: string;
    blur: number;
    active: boolean;
    onSelect: () => void;
  }) {
    const t = THEMES[id];

    return (
      <div className="flex flex-col items-center gap-5 shrink-0 snap-center h-full max-h-[640px] justify-center">
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={onSelect}
          className="relative overflow-hidden rounded-[32px] text-left transition-all shrink-0 border-[6px]"
          style={{
            width: 280,
            height: 560,
            borderColor: active ? "var(--primary)" : "var(--surface-2)",
            boxShadow: active
              ? \`0 20px 40px -12px color-mix(in oklab, var(--primary) 40%, transparent)\`
              : \`0 10px 30px -10px rgba(0,0,0,0.15)\`,
            transform: active ? "scale(1.02)" : "scale(1)",
            background: "black" // frame color
          }}
        >
          {/* Screen Content */}
          <div className="absolute inset-0 overflow-hidden bg-black pointer-events-none rounded-[26px]">
            <ChatPreview
              theme={id}
              accent={accent}
              radius={radius}
              bubble={bubble}
              wallpaper={wallpaper}
              fontSize={fontSize}
              blur={blur}
              isCard={false}
            />
            {/* Gloss reflection overlay */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent opacity-60 mix-blend-overlay" />
          </div>
          
          {/* Device Frame Notch */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[120px] h-[24px] bg-black rounded-b-[16px] pointer-events-none z-20 flex justify-center items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#111] shadow-[inset_0_0_2px_rgba(255,255,255,0.1)]" />
            <div className="w-12 h-2 rounded-full bg-[#111] shadow-[inset_0_0_2px_rgba(255,255,255,0.1)]" />
          </div>
        </motion.button>
        
        <div className="flex flex-col items-center mt-auto pb-4 shrink-0">
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-bold tracking-tight">
              {t.label}
            </h3>
            {active && (
              <span className="flex h-5 w-5 items-center justify-center rounded-full text-white shadow-sm" style={{ background: "var(--primary)" }}>
                <Check size={14} strokeWidth={3} />
              </span>
            )}
          </div>
          <p className="text-[13.5px] mt-0.5 capitalize opacity-70">
            {t.scheme} mode
          </p>
        </div>
      </div>
    );
  },
  (prev, next) => prev.active === next.active && prev.id === next.id,
);
`;

fs.writeFileSync('src/components/settings/ThemesScreen.tsx', content, 'utf8');
