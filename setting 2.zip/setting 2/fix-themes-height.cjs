const fs = require('fs');
let c = fs.readFileSync('src/components/settings/ThemesScreen.tsx', 'utf8');

c = c.replace(
  'h-[calc(100vh-64px)]',
  'h-[calc(100dvh-160px)] min-h-[500px]'
);

fs.writeFileSync('src/components/settings/ThemesScreen.tsx', c, 'utf8');
