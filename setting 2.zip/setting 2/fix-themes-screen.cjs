const fs = require('fs');
let c = fs.readFileSync('src/components/settings/ThemesScreen.tsx', 'utf8');

if (!c.includes('ChatPreview')) {
  c = `import { ChatPreview } from "./ChatPreview";\n` + c;
}

c = c.replace(
  /<div\n          className="mb-4 h-32 w-full rounded-2xl overflow-hidden relative shadow-sm border border-\[color-mix\(in_oklab,var\(--border\)_50%,transparent\)\]"\n          style=\{\{ background: `\$\{t\.wallpaper\}, \$\{t\.bg\}` \}\}\n        >[\s\S]*?<\/div>\n        <\/div>/,
  `<div
          className="mb-4 h-[180px] w-full rounded-[20px] overflow-hidden relative shadow-sm border border-[color-mix(in_oklab,var(--border)_50%,transparent)]"
        >
          <div className="absolute inset-0 pointer-events-none scale-[1.0] transform-gpu origin-top">
            <ChatPreview
              theme={id}
              accent="violet"
              radius={18}
              bubble="rounded"
              wallpaper="crypto"
              fontSize="14.5px"
              blur={22}
              isCard={true}
            />
          </div>
          <div className="absolute inset-0 ring-1 ring-inset ring-black/5 rounded-[20px]" />
        </div>`
);

fs.writeFileSync('src/components/settings/ThemesScreen.tsx', c, 'utf8');
