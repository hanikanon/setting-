const fs = require('fs');
let c = fs.readFileSync('src/components/settings/ThemesScreen.tsx', 'utf8');

c = c.replace(
  /function ThemeGalleryCard\(\{[\s\S]*?id: ThemeId;/,
  `function ThemeGalleryCard({
    id,
    active,
    onSelect,
    accent,
    radius,
    bubble,
    wallpaper,
    fontSize,
    blur,
  }: {
    id: ThemeId;
    accent: any;
    radius: number;
    bubble: any;
    wallpaper: string;
    fontSize: string;
    blur: number;`
);

c = c.replace(
  /<ThemeGalleryCard key=\{id\} id=\{id\} active=\{s\.theme === id\} onSelect=\{[^}]+\} \/>/,
  `<ThemeGalleryCard 
          key={id} 
          id={id} 
          active={s.theme === id} 
          onSelect={() => s.setTheme(id)} 
          accent={s.accent}
          radius={s.radius}
          bubble={s.bubble}
          wallpaper={s.wallpaper}
          fontSize="14.5px"
          blur={s.blur}
        />`
);

c = c.replace(
  /accent="violet"\n              radius=\{18\}\n              bubble="rounded"\n              wallpaper="crypto"\n              fontSize="14\.5px"\n              blur=\{22\}/,
  `accent={accent}
              radius={radius}
              bubble={bubble}
              wallpaper={wallpaper}
              fontSize={fontSize}
              blur={blur}`
);

fs.writeFileSync('src/components/settings/ThemesScreen.tsx', c, 'utf8');
