const fs = require('fs');
let c = fs.readFileSync('src/components/settings/Toggle.tsx', 'utf8');
c = c.replace(/layout\n\s*transition/, 'transition');
c = c.replace(/className="ml-0.5 block h-\[22px\] w-\[22px\] rounded-full bg-white shadow-md"\n\s*style=\{\{ marginLeft: checked \? 20 : 2 \}\}/, 
`className="block h-[22px] w-[22px] rounded-full bg-white shadow-[0_2px_8px_rgb(0,0,0,0.15)] ring-1 ring-black/5"
          initial={false}
          animate={{ x: checked ? 20 : 2 }}`);
fs.writeFileSync('src/components/settings/Toggle.tsx', c, 'utf8');
