const fs = require('fs');

function fixFile(file, replacer) {
  let content = fs.readFileSync(file, 'utf8');
  content = replacer(content);
  fs.writeFileSync(file, content, 'utf8');
}

fixFile('src/routes/settings.privacy.tsx', c => {
  let cc = c.replace(/as any/g, 'as unknown as "everyone" | "contacts" | "nobody"');
  cc = cc.replace(/as unknown as "everyone" \| "contacts" \| "nobody"\)\}/g, 'as unknown as any)}');
  return cc;
});

fixFile('src/routes/settings.security.recovery.tsx', c => {
  return c.replace(/as any/g, 'as unknown as "none" | "email" | "phone" | "google"');
});

console.log('done fixes final');
