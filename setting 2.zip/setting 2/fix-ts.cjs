const fs = require('fs');
let c = fs.readFileSync('src/components/settings/SettingsContext.tsx', 'utf8');

c = c.replace(/type WallpaperId =[\s\S]*?\| "aurora"/, 'type WallpaperId =\n  | "crypto"\n  | "aurora"');
c = c.replace(/type WallpaperId =[\s\S]*?\| "aurora"/, 'type WallpaperId =\n  | "crypto"\n  | "aurora"'); // just in case

fs.writeFileSync('src/components/settings/SettingsContext.tsx', c, 'utf8');

let c2 = fs.readFileSync('src/components/settings/ChatPreview.tsx', 'utf8');
c2 = c2.replace(/WALLPAPERS\[wallpaper as any\]\?\.value/, 'WALLPAPERS[wallpaper as keyof typeof WALLPAPERS]?.value');
fs.writeFileSync('src/components/settings/ChatPreview.tsx', c2, 'utf8');
