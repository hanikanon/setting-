const fs = require('fs');
let c = fs.readFileSync('src/components/settings/SettingsContext.tsx', 'utf8');

c = c.replace(
  'export type WallpaperId = "aurora" | "nebula" | "ocean" | "sunset" | "graphite" | "mesh";',
  'export type WallpaperId = "crypto" | "aurora" | "nebula" | "ocean" | "sunset" | "graphite" | "mesh";'
);

fs.writeFileSync('src/components/settings/SettingsContext.tsx', c, 'utf8');
