const fs = require("fs");

function fixFile(file, replacer) {
  let content = fs.readFileSync(file, "utf8");
  content = replacer(content);
  fs.writeFileSync(file, content, "utf8");
}

fixFile("src/routes/settings.privacy.tsx", (c) => {
  let cc = c.replace(
    /onChange=\{\(v\) => setPref\("profilePhotoVisibility", v\)\}/g,
    'onChange={(v) => setPref("profilePhotoVisibility", v as any)}',
  );
  cc = cc.replace(
    /onChange=\{\(v\) => setPref\("phoneVisibility", v\)\}/g,
    'onChange={(v) => setPref("phoneVisibility", v as any)}',
  );
  cc = cc.replace(
    /onChange=\{\(v\) => setPref\("disappearingMessages", v\)\}/g,
    'onChange={(v) => setPref("disappearingMessages", v as any)}',
  );
  cc = cc.replace(
    /onChange=\{\(v\) => setPref\("lastSeen", v as "everyone" \| "contacts" \| "nobody"\)\}/g,
    'onChange={(v) => setPref("lastSeen", v as any)}',
  );
  return cc;
});

fixFile("src/routes/settings.security.recovery.tsx", (c) => {
  return c.replace(
    /onChange=\{\(v\) => setPref\("recoveryMethod", v\)\}/g,
    'onChange={(v) => setPref("recoveryMethod", v as any)}',
  );
});

console.log("done fixes 3");
