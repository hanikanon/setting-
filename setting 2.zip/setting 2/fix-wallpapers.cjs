const fs = require('fs');
let c = fs.readFileSync('src/components/settings/SettingsContext.tsx', 'utf8');

if (!c.includes('crypto: {')) {
  c = c.replace(
    'aurora: {',
    `crypto: {
    label: "Crypto",
    value: "url('/crypto-pattern.svg')",
  },
  aurora: {`
  );
  c = c.replace(/type WallpaperId =\n\s*\| "aurora"/, 'type WallpaperId =\n  | "crypto"\n  | "aurora"');
}

fs.writeFileSync('src/components/settings/SettingsContext.tsx', c, 'utf8');
