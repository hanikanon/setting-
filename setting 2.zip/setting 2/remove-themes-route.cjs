const fs = require('fs');
let c = fs.readFileSync('src/routes/index.tsx', 'utf8');

c = c.replace(
  /  \{\s*path: "\/settings\/themes",\s*label: "Browse Themes",\s*description: "Explore color themes gallery",\s*icon: Brush,\s*group: "Experience",\s*\},/,
  ''
);

fs.writeFileSync('src/routes/index.tsx', c, 'utf8');
