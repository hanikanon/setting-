const fs = require('fs');
let c = fs.readFileSync('src/routes/index.tsx', 'utf8');

c = c.replace(
  'description: "Wallpaper, text size, backup",',
  'description: "Auto-download, composer, backups",'
);

fs.writeFileSync('src/routes/index.tsx', c, 'utf8');
