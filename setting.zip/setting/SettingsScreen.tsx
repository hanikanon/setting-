import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import type { ReactNode } from "react";
import { useCanGoBack, useRouter } from "@tanstack/react-router";
import { useSettings } from "./SettingsContext";

export function SettingsScreen({
  title,
  children,
  right,
}: {
  title: string;
  children: ReactNode;
  right?: ReactNode;
}) {
  const s = useSettings();
  const speed = s.motion === "fast" ? 0.14 : s.motion === "reduced" ? 0 : 0.24;
  const ease: [number, number, number, number] = [0.16, 1, 0.3, 1];
  const router = useRouter();
  const canGoBack = useCanGoBack();
  const goBack = () => {
    if (canGoBack) router.history.back();
    else router.navigate({ to: "/" });
  };

  return (
    <div className="mx-auto flex min-h-svh w-full max-w-[520px] flex-col md:max-w-[560px]">
      <motion.header
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: speed || 0.01, ease }}
        className="glass sticky top-0 z-20 flex items-center gap-2 px-4 py-3"
        style={{ paddingTop: "max(env(safe-area-inset-top), 12px)" }}
      >
        <motion.button
          initial={{ opacity: 0, x: -6 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.2 }}
          onClick={goBack}
          className="press flex h-9 w-9 items-center justify-center rounded-xl text-foreground hover:bg-[color-mix(in_oklab,var(--foreground)_6%,transparent)]"
          aria-label="Back"
        >
          <ArrowLeft size={20} />
        </motion.button>
        <motion.h1
          key={title}
          initial={{ opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="flex-1 truncate text-[17px] font-semibold tracking-tight text-foreground"
        >
          {title}
        </motion.h1>
        {right}
      </motion.header>

      <main className="flex-1 pb-16 pt-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={title}
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -24 }}
            transition={{ duration: speed, ease }}
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
