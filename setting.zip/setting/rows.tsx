import { motion } from "framer-motion";
import type { ComponentType, ReactNode } from "react";
import { Check } from "lucide-react";
import { SettingItem } from "./SettingItem";
import { Toggle } from "./Toggle";

type IconType = ComponentType<{ className?: string; size?: number; strokeWidth?: number }>;

export function RowToggle({
  icon: Icon,
  label,
  description,
  checked,
  onChange,
  last,
}: {
  icon: IconType;
  label: string;
  description?: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  last?: boolean;
}) {
  return (
    <SettingItem
      icon={Icon}
      label={label}
      description={description}
      showArrow={false}
      last={last}
      onClick={() => onChange(!checked)}
      trailing={<Toggle checked={checked} onChange={onChange} label={label} />}
    />
  );
}

export function RowChoice<T extends string>({
  icon: Icon,
  label,
  description,
  value,
  options,
  onChange,
  last,
}: {
  icon: IconType;
  label: string;
  description?: string;
  value: T;
  options: { value: T; label: string }[];
  onChange: (v: T) => void;
  last?: boolean;
}) {
  const current = options.find((o) => o.value === value)?.label ?? String(value);
  return (
    <SettingItem
      icon={Icon}
      label={label}
      description={description}
      last={last}
      trailing={current}
      showArrow
      onClick={() => {
        const i = options.findIndex((o) => o.value === value);
        const next = options[(i + 1) % options.length];
        onChange(next.value);
      }}
    />
  );
}

export function RadioList<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { value: T; label: string; description?: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <>
      {options.map((o, i) => (
        <motion.button
          key={o.value}
          type="button"
          whileTap={{ scale: 0.99 }}
          onClick={() => onChange(o.value)}
          className={[
            "flex w-full items-center gap-3 px-4 py-3 text-left transition-colors",
            "hover:bg-[color-mix(in_oklab,var(--foreground)_4%,transparent)]",
            i !== options.length - 1 ? "border-b border-border" : "",
          ].join(" ")}
        >
          <div className="min-w-0 flex-1">
            <p className="truncate text-[15px] font-medium leading-tight text-foreground">
              {o.label}
            </p>
            {o.description && (
              <p className="mt-0.5 truncate text-[12.5px] text-muted-foreground">
                {o.description}
              </p>
            )}
          </div>
          {value === o.value ? (
            <span
              className="flex h-5 w-5 items-center justify-center rounded-full"
              style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}
            >
              <Check size={13} strokeWidth={3} />
            </span>
          ) : (
            <span
              className="h-5 w-5 rounded-full border"
              style={{ borderColor: "color-mix(in oklab, var(--foreground) 20%, transparent)" }}
            />
          )}
        </motion.button>
      ))}
    </>
  );
}

export function InfoRow({
  label,
  value,
}: {
  label: string;
  value: ReactNode;
}) {
  return (
    <div className="flex items-center justify-between border-b border-border px-4 py-3 last:border-b-0">
      <span className="text-[13px] text-muted-foreground">{label}</span>
      <span className="text-[14px] font-medium text-foreground">{value}</span>
    </div>
  );
}
