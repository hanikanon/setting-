import { createFileRoute } from "@tanstack/react-router";
import { SettingsScreen } from "@/components/settings/SettingsScreen";
import { AppearanceScreen } from "@/components/settings/AppearanceScreen";

export const Route = createFileRoute("/settings/appearance")({
  component: Page,
});

function Page() {
  return (
    <SettingsScreen title="Appearance">
      <AppearanceScreen />
    </SettingsScreen>
  );
}
